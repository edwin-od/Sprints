const Project = require('../models/project');

const getProjects = async (req, res, next) => {
	try{
		const projects = await Project.find();
		res.status(200).json({projects: projects});
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const getProject = async (req, res, next) => {
	try{
		const projectId = req.params.projectId;
		const project = await Project.findById(projectId);
		if(!project){
			const error = new Error('Project Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json({project: project});
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const addProject = async (req, res, next) => {	
	const project = new Project({
		projectName: req.body.projectName,
		clientName: req.body.clientName,
		deliveryDate: req.body.deliveryDate
	});
	try{
		const result = await project.save();
		res.status(201).json();	
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const updateProject = async (req, res, next) => {
	const projectId = req.params.projectId;
	try{
		const result = await Project.updateOne(
			{_id: projectId},
			{$set: req.body}
		);
		res.status(200).json();
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const deleteProject = async (req, res, next) => {
	const projectId = req.params.projectId;
	try{
		await Project.findOneAndRemove(projectId);
		res.status(200).json();
	}catch(error){
		if(!err.statusCode){
			err.statusCode = 500;
		}
		next(err);
	}
}

module.exports = { 
	getProjects: getProjects, 
	getProject: getProject, 
	addProject: addProject, 
	updateProject: updateProject, 
	deleteProject: deleteProject 
};