const { validationResult } = require('express-validator');

const Project = require('../models/project');

exports.getProjects = (req, res, next) => {
	Project.find()
	.then(projects => {
		res.status(200).json({message: 'Projects Fetched Successfully', projects: projects});
	})
	.catch(err => {
		if(!err.statusCode){
			err.statusCode = 500;
		}
		next(err);
	});
}

exports.getProject = (req, res, next) => {
	const projectId = req.params.projectId;
	Project.findById(projectId)
	.then(project => {
		if(!project){
			const error = new Error('Project Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json({message:'Project Found Successfully', project: project});
	})
	.catch(err => {
		if(!err.statusCode){
			err.statusCode = 500;
		}
		next(err);
	});
}

exports.addProject = (req, res, next) => {
	//For browser first permission request
	if(req.method.toString() === 'OPTIONS'){
		return res.status(200).json({});
	}	
	
	const errors = validationResult(req);
	if(!errors.isEmpty()){
		const error = new Error('Validation Error => project-name or client-name too short..');
		error.statusCode = 422;
		throw error;
	}

	const projectName = req.body.projectName;
	const clientName = req.body.clientName;
	const deliveryDate = req.body.deliveryDate;
	const project = new Project({
		projectName: projectName,
		clientName: clientName,
		deliveryDate: deliveryDate
	});
	project.save()
	.then(result => {
		res.status(201).json({
			message: 'New Project Added Successfully',
			project: result
		});	
	})
	.catch(err => {
		if(!err.statusCode){
			err.statusCode = 500;
		}
		next(err);
	});	
}

exports.updateProject = (req, res, next) => {
	//For browser first permission request
	if(req.method.toString() === 'OPTIONS'){
		return res.status(200).json({});
	}	
	
	const errors = validationResult(req);
	if(!errors.isEmpty()){
		const error = new Error('Validation Error => project-name or client-name too short..');
		error.statusCode = 422;
		throw error;
	}

	const projectId = req.params.projectId;
	const projectName = req.body.projectName;
	const clientName = req.body.clientName;
	const deliveryDate = req.body.deliveryDate;
	
	Project.findById(projectId)
	.then(project => {
		if(!project){
			const error = new Error('Project Not Found!');
			error.statusCode = 404;
			throw error;
		}
		project.projectName = projectName;
		project.clientName = clientName;
		project.deliveryDate = deliveryDate;
		return project.save();
	})
	.then(result => {
			res.status(200).json({message:'Project Updated Successfully', project: result});
	})
	.catch(err => {
		if(!err.statusCode){
			err.statusCode = 500;
		}
		next(err);
	});
}

exports.deleteProject = (req, res, next) => {
	const projectId = req.params.projectId;
	Project.findById(projectId)
	.then(project => {
		if(!project){
			const error = new Error('Project Not Found!');
			error.statusCode = 404;
			throw error;
		}
		return Project.findOneAndRemove(projectId);
	})
	.then(result => {
		res.status(200).json({message:'Project Deleted Successfully'});
	})
	.catch(err => {
		if(!err.statusCode){
			err.statusCode = 500;
		}
		next(err);
	});
}