const express = require('express');
const router = express.Router();

const projectController = require('../controllers/project-controller');

const { body } = require('express-validator');

router.get('/get-projects', projectController.getProjects);

router.get('/get-project/:projectId', projectController.getProject);

router.post(
	'/add-project',
	[
		body('projectName').trim().isLength({ min: 3 }),
		body('clientName').trim().isLength({ min: 3 })
	], 
	projectController.addProject);

router.put(
	'/update-project/:projectId', 
	[
		body('projectName').trim().isLength({ min: 3 }),
		body('clientName').trim().isLength({ min: 3 })
	],
	projectController.updateProject);

router.delete('/delete-project/:projectId', projectController.deleteProject);

module.exports = router;