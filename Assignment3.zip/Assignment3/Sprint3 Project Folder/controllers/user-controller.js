const User = require('../models/user');
const Sprint = require('../models/sprint');

const getUsers = async (req, res, next) => {
	try{
		const NB_USERS_PER_PAGE = 3;
		const users = await User.find().skip((((req.query.page || 1) - 1) * NB_USERS_PER_PAGE)).limit(NB_USERS_PER_PAGE);
		res.status(200).json({users: users});
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const getUser = async (req, res, next) => {
	try{
		if(!req.params.userId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		const user = await User.findById(req.params.userId);
		if(!user){
			const error = new Error('User Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json({user: user});
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const addUser = async (req, res, next) => {	
	try{
		if((new Date(req.body.employmentDate) > new Date().getTime())){
			const error = new Error('Employment Date Is Invalid!');
			error.statusCode = 409;
			throw error;
		}
		const user = new User({
			firstName: req.body.firstName,
			lastName: req.body.lastName, 
			jobTitle: req.body.jobTitle,
			employmentDate: req.body.employmentDate
		});
	
		await user.save();

		res.status(201).json();	
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const updateUser = async (req, res, next) => {
	try{
		if(!req.params.userId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		const result = await User.updateOne(
			{_id: req.params.userId},
			{$set: req.body}
		);
		if(result.n == 0){
			const error = new Error('User Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json();
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const deleteUser = async (req, res, next) => {
	try{
		if(!req.params.userId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		const refs = await Sprint.find({"employees.user": req.params.userId});
		if(refs.length != 0){
			const error = new Error('User Is Referenced In Sprint(s)');
			error.statusCode = 409;
			throw error;
		}
		const user = await User.findByIdAndRemove(req.params.userId);
		if(!user){
			const error = new Error('User Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json();
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

module.exports = { 
	getUsers: getUsers, 
	getUser: getUser, 
	addUser: addUser, 
	updateUser: updateUser, 
	deleteUser: deleteUser
};