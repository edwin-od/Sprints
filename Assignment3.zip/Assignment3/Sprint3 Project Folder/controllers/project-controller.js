const Project = require('../models/project');
const Sprint = require('../models/sprint');

const getProjects = async (req, res, next) => {
	try{
		const NB_PROJECTS_PER_PAGE = 3;
		const projects = await Project.find().skip((((req.query.page || 1) - 1) * NB_PROJECTS_PER_PAGE)).limit(NB_PROJECTS_PER_PAGE);
		res.status(200).json({projects: projects});
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const getProject = async (req, res, next) => {
	try{
		if(!req.params.projectId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		const project = await Project.findById(req.params.projectId);
		if(!project){
			const error = new Error('Project Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json({project: project});
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const addProject = async (req, res, next) => {	
	const project = new Project({
		projectName: req.body.projectName,
		clientName: req.body.clientName,
		deliveryDate: req.body.deliveryDate
	});
	try{
		await project.save();
		res.status(201).json();	
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const updateProject = async (req, res, next) => {
	try{
		if(!req.params.projectId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		const result = await Project.updateOne(
			{_id: req.params.projectId},
			{$set: req.body}
		);
		if(result.n == 0){
			const error = new Error('Project Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json();
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const deleteProject = async (req, res, next) => {
	try{
		if(!req.params.projectId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		const refs = await Sprint.find({project: req.params.projectId});
		if(refs.length != 0){
			const error = new Error('Project Is Referenced In Sprint(s)');
			error.statusCode = 409;
			throw error;
		}
		const project = await Project.findByIdAndRemove(req.params.projectId);
		if(!project){
			const error = new Error('Project Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json();
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

module.exports = { 
	getProjects: getProjects, 
	getProject: getProject, 
	addProject: addProject, 
	updateProject: updateProject, 
	deleteProject: deleteProject 
};