const express = require('express');
const app = express();

const mongoose = require('mongoose');

const bodyParser = require('body-parser');

const projectRoute = require('./routes/project-route');
const employeeRoute = require('./routes/employee-route');
const sprintRoute = require('./routes/sprint-route');

app.use((req, res, next) => {
	res.setHeader('Access-Control-Allow-Origin', '*');
	res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE');
	res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
	next();
});

app.use(bodyParser.json());

(async function(){
	try{
		await mongoose.connect(
			'mongodb+srv://test_user:test123@euriskocloudtest-kwkcx.gcp.mongodb.net/EuriskoCloudTest?retryWrites=true&w=majority', 
			{	
				useUnifiedTopology: true,
				useNewUrlParser: true,
				useFindAndModify: false
			});
		app.listen(8080);
		console.log('Connected to DB and server started on port#8080');
	}catch (err){
		console.log(err);
	}
})();

app.use('/projects', projectRoute);
app.use('/employees', employeeRoute);
app.use('/sprints', sprintRoute);

app.use((error, req, res, next) => {
	res.status(error.statusCode || 500).json({Error: error.message});
});