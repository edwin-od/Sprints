const Employee = require('../models/employee');
const Sprint = require('../models/sprint');

const getEmployees = async (req, res, next) => {
	try{
		const NB_EMPLOYEES_PER_PAGE = 3;
		const employees = await Employee.find();//.skip((((req.query.page || 1) - 1) * NB_EMPLOYEES_PER_PAGE)).limit(NB_EMPLOYEES_PER_PAGE);
		res.status(200).json({employees: employees});
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const getEmployee = async (req, res, next) => {
	try{
		if(!req.params.employeeId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		const employee = await Employee.findById(req.params.employeeId);
		if(!employee){
			const error = new Error('Employee Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json({employee: employee});
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const addEmployee = async (req, res, next) => {	
	try{
		if((new Date(req.body.employmentDate).getTime() > new Date().getTime())){
			const error = new Error('Employment Date Is Invalid!');
			error.statusCode = 409;
			throw error;
		}
		const employee = new Employee({
			firstName: req.body.firstName,
			lastName: req.body.lastName, 
			jobTitle: req.body.jobTitle,
			employmentDate: req.body.employmentDate
		});
	
		await employee.save();

		res.status(201).json();	
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const updateEmployee = async (req, res, next) => {
	try{
		if(!req.params.employeeId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		if((new Date(req.body.employmentDate).getTime() > new Date().getTime())){
			const error = new Error('Employment Date Is Invalid!');
			error.statusCode = 409;
			throw error;
		}
		await Employee.updateOne(
			{_id: req.params.employeeId},
			{$set: req.body}
		);

		res.status(200).json();
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const deleteEmployee = async (req, res, next) => {
	try{
		if(!req.params.employeeId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		const refs = await Sprint.find({"employees.employee": req.params.employeeId});
		if(refs.length != 0){
			const error = new Error('Employee Is Referenced In Sprint(s)');
			error.statusCode = 409;
			throw error;
		}
		const employee = await Employee.findByIdAndRemove(req.params.employeeId);
		if(!employee){
			const error = new Error('Employee Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json();
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

module.exports = { 
	getEmployees: getEmployees, 
	getEmployee: getEmployee, 
	addEmployee: addEmployee, 
	updateEmployee: updateEmployee, 
	deleteEmployee: deleteEmployee
};