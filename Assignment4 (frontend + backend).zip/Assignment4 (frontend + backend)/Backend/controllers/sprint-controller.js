const Sprint = require('../models/sprint');
const Employee = require('../models/employee');
const Project = require('../models/project');

const getSprints = async (req, res, next) => {
	try{
		const NB_SPRINTS_PER_PAGE = 3;
		const sprints = await Sprint.find().populate('project').populate('employees.employee');
			//.skip((((req.query.page || 1) - 1) * NB_SPRINTS_PER_PAGE)).limit(NB_SPRINTS_PER_PAGE);
		res.status(200).json({sprints: sprints});
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const getSprint = async (req, res, next) => {
	try{
		if(!req.params.sprintId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		const sprint = await Sprint.findById(req.params.sprintId).populate('project').populate('employees.employee');
		if(!sprint){
			const error = new Error('Sprint Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json({sprint: sprint});
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}		
		next(error);
	}
}

const addSprint = async (req, res, next) => {
	try{
		if(new Date(req.body.startDate).getTime() >= new Date(req.body.endDate).getTime()){
			const error = new Error('Dates Are Not Valid!');
				error.statusCode = 409;
				throw error;
		}

		const project = await Project.findOne(
			{
				$and: [
					{_id: req.body.project},
					{deliveryDate: { $gte: new Date(req.body.endDate) }},
					{createdAt: { $lt: new Date(req.body.startDate) }}
				]
			}
		);
		if(!project){
			const error = new Error('Project Is Not Valid!');
			error.statusCode = 400;
			throw error;
		}
		
		const employeeIdList = req.body.employees.map((employee) => {
			return employee.toString();
		});
		const employees = await Employee.find({_id: {$in: employeeIdList}});
		if(employees.length != req.body.employees.length){
			const error = new Error('Employees List Is Not Valid!');
			error.statusCode = 404;
			throw error;
		}

		for(let employee in req.body.employees){
			req.body.employees[employee] = {employee: req.body.employees[employee]};
		}
		
		const sprint = new Sprint({
			sprintName: req.body.sprintName,
			project: req.body.project,
			employees: req.body.employees,
			startDate: req.body.startDate,
			endDate: req.body.endDate
		});

		await sprint.save();

		res.status(201).json();	
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const updateSprint = async (req, res, next) => {	
	try{
		if(!req.params.sprintId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		if(new Date(req.body.startDate).getTime() >= new Date(req.body.endDate).getTime()){
			const error = new Error('Dates Are Not Valid!');
				error.statusCode = 409;
				throw error;
		}

		const project = await Project.findOne(
			{
				$and: [
					{_id: req.body.project},
					{deliveryDate: { $gte: new Date(req.body.endDate) }},
					{createdAt: { $lt: new Date(req.body.startDate) }}
				]
			}
		);
		if(!project){
			const error = new Error('Project Is Not Valid!');
			error.statusCode = 400;
			throw error;
		}
		
		const employeeIdList = req.body.employees.map((employee) => {
			return employee.toString();
		});
		const employees = await Employee.find({_id: {$in: employeeIdList}});
		if(employees.length != req.body.employees.length){
			const error = new Error('Employees List Is Not Valid!');
			error.statusCode = 400;
			throw error;
		}

		for(let employee in req.body.employees){
			req.body.employees[employee] = {employee: req.body.employees[employee]};
		}
		
		await Sprint.updateOne(
			{_id: req.params.sprintId},
			{$set: req.body}
		);

		res.status(200).json();
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const deleteSprint = async (req, res, next) => {	
	try{
		if(!req.params.sprintId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		const sprint = await Sprint.findByIdAndRemove(req.params.sprintId);
		if(!sprint){
			const error = new Error('Sprint Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json();
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

const addEmployees = async (req, res, next) => {
	console.log('eds');
	try{
		if(!req.params.sprintId){
			const error = new Error('ID Field Is Invalid');
			error.statusCode = 400;
			throw error;
		}
		const employeeIdList = req.body.employees.map((employee) => {
			return employee.employee.toString();
		});
		const employees = await Employee.find({_id: {$in: employeeIdList}});
		if(employees.length != req.body.employees.length){
			const error = new Error('Employees List Is Not Valid!');
			error.statusCode = 404;
			throw error;
		}
		const result = await Sprint.updateOne(
				{_id: req.params.sprintId},
				{$addToSet: {employees: {$each: req.body.employees}}}
		);
		if(result.n == 0){
			const error = new Error('Sprint Not Found!');
			error.statusCode = 404;
			throw error;
		}
		res.status(200).json();
	}catch(error){
		if(!error.statusCode){
			error.statusCode = 500;
		}
		next(error);
	}
}

module.exports = { 
	getSprints: getSprints, 
	getSprint: getSprint, 
	addSprint: addSprint, 
	updateSprint: updateSprint, 
	deleteSprint: deleteSprint,
	addEmployees: addEmployees
};