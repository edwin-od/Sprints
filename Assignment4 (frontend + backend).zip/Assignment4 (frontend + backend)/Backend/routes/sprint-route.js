const express = require('express');
const router = express.Router();

const sprintController = require('../controllers/sprint-controller');

router.get('/', sprintController.getSprints);
router.get('/:sprintId', sprintController.getSprint);

router.post('/', sprintController.addSprint);
router.post('/:sprintId', sprintController.addEmployees);

router.put('/:sprintId', sprintController.updateSprint);

router.delete('/:sprintId', sprintController.deleteSprint);

module.exports = router;