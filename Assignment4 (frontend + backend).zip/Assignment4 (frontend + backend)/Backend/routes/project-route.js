const express = require('express');
const router = express.Router();

const projectController = require('../controllers/project-controller');

router.get('/', projectController.getProjects);
router.get('/:projectId', projectController.getProject);

router.post('/', projectController.addProject);

router.put('/:projectId', projectController.updateProject);

router.delete('/:projectId', projectController.deleteProject);

module.exports = router;