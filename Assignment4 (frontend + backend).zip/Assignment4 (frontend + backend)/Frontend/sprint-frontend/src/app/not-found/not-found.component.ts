import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-not-found',
  templateUrl: './not-found.component.html',
  styleUrls: ['./not-found.component.css']
})
export class NotFoundComponent implements OnInit {

  secondsLimit: number = 10;

  count: number = 0;

  constructor(private router: Router) { }

  ngOnInit(): void {
    var t = this;
    var intervalCount = setInterval(function() {
      if(t.count >= t.secondsLimit - 1) {
        t.redirect();
        clearInterval(intervalCount);
      }
      t.count++;
    }, 1000);
  }

  getCount(): number {
    return (this.secondsLimit - this.count);
  }

  redirect() {
    this.router.navigate(['']);
  }

}
