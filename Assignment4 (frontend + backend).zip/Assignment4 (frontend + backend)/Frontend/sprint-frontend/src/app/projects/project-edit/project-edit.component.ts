import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

import { Project } from '../../shared/project.model';

import { ProjectService } from '../../shared/project.service';

@Component({
  selector: 'app-project-edit',
  templateUrl: './project-edit.component.html',
  styleUrls: ['./project-edit.component.css']
})
export class ProjectEditComponent implements OnInit {

  isEditing: boolean = true;
  isAddUpdateError: boolean = false;
  isDeleteError: boolean = false;

  projectForm: FormGroup;

  project: Project = null;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private fb: FormBuilder,
              public projectService: ProjectService) { }

  ngOnInit(): void {
    this.init();
  }

  init() {
    if(this.route.snapshot.url[0].toString() === "new") {
      this.isEditing = false;
      this.initProjectForm();      
    } else if(this.route.snapshot.url[1].toString() === "edit") {
      this.projectService.getProjectHttp(this.route.snapshot.params['id']).subscribe(resData => {
        this.project = new Project(
          resData['project']._id,
          resData['project'].projectName,
          resData['project'].clientName,
          resData['project'].deliveryDate
        );
        this.isEditing = true;  
        this.initProjectForm();      
      }, error => this.router.navigate(['']));             
    }    
  }

  initProjectForm() {
    if(this.isEditing) {
      this.projectForm = this.fb.group({
        ['projectName']: [this.project.projectName, Validators.compose([Validators.required])],
        ['clientName']: [this.project.clientName, Validators.compose([Validators.required])],
        ['deliveryDate']: [new Date(this.project.deliveryDate), Validators.compose([Validators.required, this.deliveryDateValidator])]
      });
    } else {
      this.projectForm = this.fb.group({
        ['projectName']: [null, Validators.compose([Validators.required])],
        ['clientName']: [null, Validators.compose([Validators.required])],
        ['deliveryDate']: [null, Validators.compose([Validators.required, this.deliveryDateValidator])]
      });
    }
    this.projectForm.valueChanges.subscribe((value) => {
      this.isAddUpdateError = false;
      this.isDeleteError = false;
    });
  }

  deliveryDateValidator(control: FormControl): {[s: string]: boolean} {
    let deliveryDate = new Date(control.value);
    let todayDate = new Date();
    todayDate.setHours(0);
    todayDate.setMinutes(0);
    todayDate.setSeconds(0);
    todayDate.setMilliseconds(0);

    if(deliveryDate.getTime() < todayDate.getTime()) {
      return {'deliveryDateInvalid': true};
    }
    return null;
  }

  onSubmit() {
    if(this.isEditing) {
      let p = new Project(
        this.route.snapshot.params['id'],
        this.projectForm.get('projectName').value,
        this.projectForm.get('clientName').value,
        this.adjustDateHours(this.projectForm.get('deliveryDate').value)
      );
      this.projectService.updateProjectHttp(this.route.snapshot.params['id'], p).subscribe(resData => {
          this.onCancel();
      }, error => {
        this.isAddUpdateError = true;
        this.isDeleteError = false;
      });
    } else {
      let p = new Project(
        null,
        this.projectForm.get('projectName').value,
        this.projectForm.get('clientName').value,
        this.adjustDateHours(this.projectForm.get('deliveryDate').value)
      );
      this.projectService.addProjectHttp(p).subscribe(resData => {
          this.onCancel();
      }, error => {
        this.isAddUpdateError = true;
        this.isDeleteError = false;
      });
    }
  }

  onDelete() {
    this.projectService.deleteProjectHttp(this.route.snapshot.params['id']).subscribe(resData => {
      this.router.navigate(['']);
    }, error => {
      this.isDeleteError = true;
      this.isAddUpdateError = false;
    });
  }

  onCancel() {
    if(this.isEditing){
      this.router.navigate(['..'], {relativeTo: this.route});
    } else {
      this.router.navigate(['']);
    }
  }

  adjustDateHours(date: Date): Date {
    date.setHours(date.getHours() + 12);
    date.setMinutes(0);
    date.setSeconds(0);
    date.setMilliseconds(0);
    return date;
  }

}
