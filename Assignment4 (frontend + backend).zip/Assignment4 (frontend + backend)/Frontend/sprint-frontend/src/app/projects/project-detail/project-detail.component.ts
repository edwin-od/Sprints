import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

import { Project } from '../../shared/project.model';

import { ProjectService } from '../../shared/project.service';

@Component({
  selector: 'app-project-detail',
  templateUrl: './project-detail.component.html',
  styleUrls: ['./project-detail.component.css']
})
export class ProjectDetailComponent implements OnInit {

  project: Project = null;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private http: HttpClient,
              private projectService: ProjectService) { }

  ngOnInit(): void {
    this.projectService.getProjectHttp(this.route.snapshot.params['id']).subscribe(resData => {
      this.project = new Project(
        resData['project']._id,
        resData['project'].projectName,
        resData['project'].clientName,
        resData['project'].deliveryDate
      );
    }, error => this.router.navigate(['']));
  }

  onEditProject() {
    this.router.navigate(['edit'], {relativeTo: this.route});
  }

  onExit() {
    this.router.navigate(['']);
  }

}
