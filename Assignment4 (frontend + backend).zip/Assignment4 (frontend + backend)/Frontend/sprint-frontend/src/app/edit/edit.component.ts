import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { SprintService } from '../shared/sprint.service';
import { EmployeeService } from '../shared/employee.service';
import { ProjectService } from '../shared/project.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  use = -1;

  constructor(private router: Router,
              public s: SprintService,
              public e: EmployeeService,
              public p: ProjectService) { }

  ngOnInit(): void {
    if(this.router.url.split('/')[1].toString() === "sprints") {
      this.use = 2;
      this.s.init();
    } else if(this.router.url.split('/')[1].toString() === "projects") {
      this.use = 0;
      this.p.init();
    } else if(this.router.url.split('/')[1].toString() === "employees") {
      this.use = 1;
      this.e.init();
    }
  }
}
