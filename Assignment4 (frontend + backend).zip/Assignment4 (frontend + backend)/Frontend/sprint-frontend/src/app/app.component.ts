import { Component } from '@angular/core';

import { ProjectService } from './shared/project.service';
import { EmployeeService } from './shared/employee.service';
import { SprintService } from './shared/sprint.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(public projectService: ProjectService,
              public employeeService: EmployeeService,
              public sprintService: SprintService) {}
  title = 'sprint-frontend';
}
