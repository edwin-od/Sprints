import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

import { Employee } from '../../shared/employee.model';

import { EmployeeService } from '../../shared/employee.service';


@Component({
  selector: 'app-employee-detail',
  templateUrl: './employee-detail.component.html',
  styleUrls: ['./employee-detail.component.css']
})
export class EmployeeDetailComponent implements OnInit {

  employee: Employee = null;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private http: HttpClient,
              private employeeService: EmployeeService) { }

  ngOnInit(): void {
    this.employeeService.getEmployeeHttp(this.route.snapshot.params['id']).subscribe(resData => {
      this.employee = new Employee(
        resData['employee']._id,
        resData['employee'].firstName,
        resData['employee'].lastName,
        resData['employee'].jobTitle,
        resData['employee'].employmentDate
      );
    }, error => this.router.navigate(['']));
  }

  onEditEmployee() {
    this.router.navigate(['edit'], {relativeTo: this.route});
  }

  onExit() {
    this.router.navigate(['']);
  }

}
