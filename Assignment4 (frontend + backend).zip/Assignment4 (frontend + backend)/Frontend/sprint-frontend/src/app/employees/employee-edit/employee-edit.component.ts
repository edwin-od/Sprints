import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

import { Employee } from '../../shared/employee.model';

import { EmployeeService } from '../../shared/employee.service';

@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.css']
})
export class EmployeeEditComponent implements OnInit {

  isEditing: boolean = true;
  isAddUpdateError: boolean = false;
  isDeleteError: boolean = false;

  employeeForm: FormGroup;

  employee: Employee = null;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private fb: FormBuilder,
              public employeeService: EmployeeService) { }

  ngOnInit(): void {
    this.init();
  }

  init() {
    if(this.route.snapshot.url[0].toString() === "new") {
      this.isEditing = false;
      this.initEmployeeForm();      
    } else if(this.route.snapshot.url[1].toString() === "edit") {
      this.employeeService.getEmployeeHttp(this.route.snapshot.params['id']).subscribe(resData => {
        this.employee = new Employee(
          resData['employee']._id,
          resData['employee'].firstName,
          resData['employee'].lastName,
          resData['employee'].jobTitle,
          resData['employee'].employmentDate
        );
        this.isEditing = true;  
        this.initEmployeeForm();      
      }, error => this.router.navigate(['']));             
    }    
  }

  initEmployeeForm() {
    if(this.isEditing) {
      this.employeeForm = this.fb.group({
        ['firstName']: [this.employee.firstName, Validators.compose([Validators.required])],
        ['lastName']: [this.employee.lastName, Validators.compose([Validators.required])],
        ['jobTitle']: [this.employee.jobTitle, Validators.compose([Validators.required])],
        ['employmentDate']: [new Date(this.employee.employmentDate), Validators.compose([Validators.required, this.employmentDateValidator])]
      });
    } else {
      this.employeeForm = this.fb.group({
        ['firstName']: [null, Validators.compose([Validators.required])],
        ['lastName']: [null, Validators.compose([Validators.required])],
        ['jobTitle']: [null, Validators.compose([Validators.required])],
        ['employmentDate']: [null, Validators.compose([Validators.required, this.employmentDateValidator])]
      });
    }
    this.employeeForm.valueChanges.subscribe((value) => {
      this.isAddUpdateError = false;
      this.isDeleteError = false;
    });
  }

  employmentDateValidator(control: FormControl): {[s: string]: boolean} {
    let employmentDate = new Date(control.value);
    let todayDate = new Date();
    todayDate.setHours(12);
    todayDate.setMinutes(0);
    todayDate.setSeconds(0);
    todayDate.setMilliseconds(0);

    if(employmentDate.getTime() > todayDate.getTime()) {
      return {'employmentDateInvalid': true};
    }
    return null;
  }

  onSubmit() {
    if(this.isEditing) {
      let e = new Employee(
        this.route.snapshot.params['id'],
        this.employeeForm.get('firstName').value,
        this.employeeForm.get('lastName').value,
        this.employeeForm.get('jobTitle').value,
        this.adjustDateHours(this.employeeForm.get('employmentDate').value)
      );
      this.employeeService.updateEmployeeHttp(this.route.snapshot.params['id'], e).subscribe(resData => {
          this.onCancel();
      }, error => {
        this.isAddUpdateError = true;
        this.isDeleteError = false;
      });
    } else {
      let e = new Employee(
        null,
        this.employeeForm.get('firstName').value,
        this.employeeForm.get('lastName').value,
        this.employeeForm.get('jobTitle').value,
        this.adjustDateHours(this.employeeForm.get('employmentDate').value)
      );
      this.employeeService.addEmployeeHttp(e).subscribe(resData => {
          this.onCancel();
      }, error => {
        this.isAddUpdateError = true;
        this.isDeleteError = false;
      });
    }
  }

  onDelete() {
    this.employeeService.deleteEmployeeHttp(this.route.snapshot.params['id']).subscribe(resData => {
      this.router.navigate(['']);
    }, error => {
      this.isDeleteError = true;
      this.isAddUpdateError = false;
    });
  }

  onCancel() {
    if(this.isEditing){
      this.router.navigate(['..'], {relativeTo: this.route});
    } else {
      this.router.navigate(['']);
    }
  }

  adjustDateHours(date: Date): Date {
    date.setHours(date.getHours() + 12);
    date.setMinutes(0);
    date.setSeconds(0);
    date.setMilliseconds(0);
    return date;
  }

}
