import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LandingComponent } from './landing/landing.component';
import { ProjectEditComponent } from './projects/project-edit/project-edit.component';
import { EmployeeEditComponent } from './employees/employee-edit/employee-edit.component';
import { SprintEditComponent } from './sprints/sprint-edit/sprint-edit.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { ProjectDetailComponent } from './projects/project-detail/project-detail.component';
import { EmployeeDetailComponent } from './employees/employee-detail/employee-detail.component';
import { SprintDetailComponent } from './sprints/sprint-detail/sprint-detail.component';
import { ProjectsComponent } from './projects/projects.component';
import { EmployeesComponent } from './employees/employees.component';
import { SprintsComponent } from './sprints/sprints.component';

import { EmployeesResolver } from './landing/employee-list/employees-resolver.service';
import { ProjectsResolver } from './landing/project-list/projects-resolver.service';
import { SprintsResolver } from './landing/sprint-list/sprints-resolver.service';

const appRoutes: Routes = [
  {path: '', component: LandingComponent, resolve: {
      employeesResolver: EmployeesResolver,
      projectsResolver: ProjectsResolver,
      sprintsResolver: SprintsResolver
    }
  },
  {path: 'projects', component: ProjectsComponent, children: [    
    {path: 'new', component: ProjectEditComponent},
    {path: ':id', component: ProjectDetailComponent},
    {path: ':id/edit', component: ProjectEditComponent},
    {path: '**', redirectTo: '404'}
  ]},
  {path: 'employees', component: EmployeesComponent, children: [
    {path: 'new', component: EmployeeEditComponent},
    {path: ':id', component: EmployeeDetailComponent},
    {path: ':id/edit', component: EmployeeEditComponent},
    {path: '**', redirectTo: '404'}
  ]},
  {path: 'sprints', component: SprintsComponent, children: [
    {path: 'new', component: SprintEditComponent},
    {path: ':id', component: SprintDetailComponent},
    {path: ':id/edit', component: SprintEditComponent},
    {path: '**', redirectTo: '404'}   
  ]},
  {path: '404', component: NotFoundComponent},
  {path: '**', redirectTo: '404', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule],
  providers: [
    EmployeesResolver,
    ProjectsResolver,
    SprintsResolver
  ]
})
export class AppRoutingModule { }
