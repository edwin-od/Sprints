import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LandingComponent } from './landing/landing.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { EditComponent } from './edit/edit.component';

import { EmployeesResolver } from './landing/employees-resolver.service';
import { ProjectsResolver } from './landing/projects-resolver.service';
import { SprintsResolver } from './landing/sprints-resolver.service';

const appRoutes: Routes = [
    {path: 'landing', component: LandingComponent, resolve: {
      employeesResolver: EmployeesResolver,
      projectsResolver: ProjectsResolver,
      sprintsResolver: SprintsResolver
    }
  },
  {path: 'projects', component: EditComponent, children: [    
    {path: 'new', component: EditComponent},
    {path: ':id', component: EditComponent},
    {path: '**', redirectTo: '404'}
  ]},
  {path: 'employees', component: EditComponent, children: [
    {path: 'new', component: EditComponent},
    {path: ':id', component: EditComponent},
    {path: '**', redirectTo: '404'}
  ]},
  {path: 'sprints', component: EditComponent, children: [
    {path: 'new', component: EditComponent},
    {path: ':id', component: EditComponent},
    {path: '**', redirectTo: '404'}   
  ]},
  {path: '', redirectTo: 'landing', pathMatch: 'full'},
  {path: '404', component: NotFoundComponent},
  {path: '**', redirectTo: '404', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule],
  providers: [
    EmployeesResolver,
    ProjectsResolver,
    SprintsResolver
  ]
})
export class AppRoutingModule { }
