import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sprints',
  templateUrl: './sprints.component.html',
  styleUrls: ['./sprints.component.css']
})
export class SprintsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
