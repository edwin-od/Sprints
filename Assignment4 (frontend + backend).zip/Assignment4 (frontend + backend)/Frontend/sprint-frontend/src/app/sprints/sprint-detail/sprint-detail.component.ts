import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

import { Sprint } from '../../shared/sprint.model';

import { SprintService } from '../../shared/sprint.service';

@Component({
  selector: 'app-sprint-detail',
  templateUrl: './sprint-detail.component.html',
  styleUrls: ['./sprint-detail.component.css']
})
export class SprintDetailComponent implements OnInit {

  sprint: Sprint = null;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private http: HttpClient,
              private sprintService: SprintService) { }

  ngOnInit(): void {
    this.sprintService.getSprintHttp(this.route.snapshot.params['id']).subscribe(resData => {
      this.sprint = new Sprint(
        resData['sprint']._id,
        resData['sprint'].sprintName,
        resData['sprint'].project,
        resData['sprint'].employees,
        resData['sprint'].startDate,
        resData['sprint'].endDate
      );
    }, error => this.router.navigate(['']));
  }

  onEditSprint() {
    this.router.navigate(['edit'], {relativeTo: this.route});
  }

  onExit() {
    this.router.navigate(['']);
  }

}
