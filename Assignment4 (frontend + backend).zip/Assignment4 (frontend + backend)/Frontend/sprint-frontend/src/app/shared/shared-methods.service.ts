import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class SharedMethods {
  adjustDateHours(date: Date): Date {
    date.setHours(date.getHours() + 12);
    date.setMinutes(0);
    date.setSeconds(0);
    date.setMilliseconds(0);
    return date;
  }
}
