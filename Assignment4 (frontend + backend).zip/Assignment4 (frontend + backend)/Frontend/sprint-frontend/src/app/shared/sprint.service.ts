import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, FormArray, Validators, FormBuilder } from '@angular/forms';
import { map } from 'rxjs/operators';

import { Sprint } from './sprint.model';

import { EmployeeService } from './employee.service';
import { ProjectService } from './project.service';
import { SharedMethods } from './shared-methods.service';

import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class SprintService {

  sprints: Sprint[] = [];

  title = 'Sprints';
  
  newRoute = '/sprints/new';
  defaultRoute = '/sprints';

  isEditing: boolean = true;
  isError: boolean = false;

  errorMessage: string = '';

  selectedEmployeeId: string;
  
  sprintForm: FormGroup;
  employee: FormArray

  sprint: Sprint = null;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private fb: FormBuilder,
              private http: HttpClient,
              private sharedMethods: SharedMethods,
              public employeeService: EmployeeService,
              public projectService: ProjectService) { }

  getSprintsHttp() {
    return this.http.get(environment.BACK_URL + 'sprints');
  }
  getSprintHttp(_id: string) {
    return this.http.get(environment.BACK_URL + 'sprints/' + _id);
  }
  updateSprintHttp(_id: string, sprint: Sprint) {
    return this.http.put(environment.BACK_URL + 'sprints/' + _id, sprint);
  }
  addSprintHttp(sprint: Sprint) {
    return this.http.post(environment.BACK_URL + 'sprints', sprint);
  }
  deleteSprintHttp(_id: string) {
    return this.http.delete(environment.BACK_URL + 'sprints/' + _id);
  }

  init() {
    this.isError = false;
    this.errorMessage = '';
    if(this.router.url.split('/')[2].toString() === "new") {
      this.projectService.getProjectsHttp().subscribe(resData => {
        this.projectService.setProjects(resData['projects']);
        this.employeeService.getEmployeesHttp().subscribe(resData => {
          this.employeeService.setEmployees(resData['employees']);
          this.isEditing = false;
          this.initSprintForm();
        }, error => {
          this.errorMessage = error.error.Error;
          this.isError = true;
        });
      }, error => {
        this.errorMessage = error.error.Error;
        this.isError = true;
      });      
    } else {
      this.getSprintHttp(this.router.url.split('/')[2].toString()).subscribe(resData => {
        this.sprint = new Sprint(
          resData['sprint']._id,
          resData['sprint'].sprintName,
          resData['sprint'].project,
          resData['sprint'].employees,
          resData['sprint'].startDate,
          resData['sprint'].endDate
        );
        this.projectService.getProjectsHttp().subscribe(resData => {
          this.projectService.setProjects(resData['projects']);
          this.employeeService.getEmployeesHttp().subscribe(resData => {
            this.employeeService.setEmployees(resData['employees']);
            this.isEditing = true;  
            this.initSprintForm();
          }, error => {
            this.errorMessage = error.error.Error;
            this.isError = true;
          });
        }, error => {
          this.errorMessage = error.error.Error;
          this.isError = true;
        });        
      }, error => {
        this.errorMessage = error.error.Error;
        this.isError = true;
      });              
    }    
  }

  initSprintForm() {
    if(this.isEditing) {
      this.sprintForm = this.fb.group({
        ['sprintName']: [this.sprint.sprintName, Validators.compose([Validators.required])],
        ['project']: [this.sprint.project._id, Validators.compose([Validators.required])],
        ['employees']: this.fb.array([], [this.employeesArrayValidator]),
        ['startDate']: [new Date(this.sprint.startDate), Validators.compose([Validators.required, this.startDateValidator])],
        ['endDate']: [new Date(this.sprint.endDate), Validators.compose([Validators.required])]
      });

      const employeeArray: FormArray = this.sprintForm.get('employees') as FormArray;
      for(let employeeChecked in this.sprint.employees.map(employee => employee.employee._id)) {
        for(let employee in this.employeeService.employees.map(employee => employee._id)) {
          if(this.employeeService.employees[employee]._id === this.sprint.employees[employeeChecked].employee._id) {
            employeeArray.insert(0, new FormControl(this.employeeService.employees[employee]._id));
          }
        }
      }
    } else {
      this.sprintForm = this.fb.group({
        ['sprintName']: [null, Validators.compose([Validators.required])],
        ['project']: [null, Validators.compose([Validators.required])],
        ['employees']: this.fb.array([], [this.employeesArrayValidator]),
        ['startDate']: [null, Validators.compose([Validators.required, this.startDateValidator])],
        ['endDate']: [null, Validators.compose([Validators.required])]
      });
    }
    this.sprintForm.valueChanges.subscribe((value) => {
      this.isError = false;
      this.errorMessage = '';
    });
  }

  startDateValidator(control: FormControl): {[s: string]: boolean} {
    let startDate = new Date(control.value);
    let todayDate = new Date();
    todayDate.setHours(0);
    todayDate.setMinutes(0);
    todayDate.setSeconds(0);
    todayDate.setMilliseconds(0);

    if(todayDate.getTime() > startDate.getTime()) {
      return {'startDateInvalid': true};
    }
    return null;
  }

  employeesArrayValidator(array: FormArray): {[s: string]: boolean} {
    if(array.length === 0){
      return {'employeesArrayInvalid': true};
    }
    return null;
  }

  removeProject() {
    this.sprintForm.controls['project'].setValue(null);
  }

  checkProjectChosen(_id: string): boolean {
    return this.sprintForm.get('project').value === _id;
  }

  onProjectChange(event) {
    this.sprintForm.controls['project'].setValue(event.target.value);    
  }  

  removeEmployee(_id: string) {
    const employeeArray: FormArray = this.sprintForm.get('employees') as FormArray;
    let i = 0;
    employeeArray.controls.forEach((ctrl: FormControl) => {
      if(ctrl.value === _id) {
        employeeArray.removeAt(i);
        return;
      }
      i++;
    });
  }

  checkAddedEmployees(_id: string): boolean {
    return (<FormArray>this.sprintForm.get('employees')).controls.map(employeeControl => employeeControl.value).includes(_id);
  }

  onAddEmployee(event) {
    (this.sprintForm.get('employees') as FormArray).insert(0, new FormControl(event.target.value));
  }
    
  onChangeEmployee(event) {
    const employeeArray: FormArray = this.sprintForm.get('employees') as FormArray;
    let i = 0;
    employeeArray.controls.forEach((ctrl: FormControl) => {
      if(ctrl.value === this.selectedEmployeeId) {
        employeeArray.removeAt(i);
        employeeArray.insert(i, new FormControl(event.target.value));
        return;
      }
      i++;
    });
  }

  onSubmit() {
    if(this.isEditing) {
      let s = new Sprint(
        this.route.snapshot.params['id'],
        this.sprintForm.get('sprintName').value,
        this.sprintForm.get('project').value,
        this.sprintForm.get('employees').value,
        this.sharedMethods.adjustDateHours(this.sprintForm.get('startDate').value),
        this.sharedMethods.adjustDateHours(this.sprintForm.get('endDate').value)
      );
      this.updateSprintHttp(this.router.url.split('/')[2].toString(), s).subscribe(resData => {
          this.onCancel();
      }, error => {
        this.errorMessage = error.error.Error;
        this.isError = true;
      });
    } else {
      let s = new Sprint(
        null,
        this.sprintForm.get('sprintName').value,
        this.sprintForm.get('project').value,
        this.sprintForm.get('employees').value,
        this.sharedMethods.adjustDateHours(this.sprintForm.get('startDate').value),
        this.sharedMethods.adjustDateHours(this.sprintForm.get('endDate').value)
      );
      this.addSprintHttp(s).subscribe(resData => {
          this.onCancel();
      }, error => {
        this.errorMessage = error.error.Error;
        this.isError = true;
      });
    }
  }

  onDelete() {
    this.deleteSprintHttp(this.router.url.split('/')[2].toString()).subscribe(resData => {
      this.onCancel();
    }, error => {
      this.errorMessage = error.error.Error;
      this.isError = true;
    });
  }

  onCancel() {
    this.sprintForm = null;
    this.router.navigate(['']);    
  }

}
