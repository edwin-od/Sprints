import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

import { Employee } from './employee.model';

import { SharedMethods } from './shared-methods.service';

import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class EmployeeService {

  employees: Employee[] = [];

  title = 'Employees';

  newRoute = '/employees/new';
  defaultRoute = '/employees';

  isEditing: boolean = true;
  isError: boolean = false;

  errorMessage: string = '';

  employeeForm: FormGroup;

  employee: Employee = null;


  constructor(private route: ActivatedRoute,
              private router: Router,
              private fb: FormBuilder,
              private http: HttpClient,
              private sharedMethods: SharedMethods) { }
  getEmployeesHttp() {
    return this.http.get(environment.BACK_URL + 'employees');
  }
  getEmployeeHttp(_id: string) {
    return this.http.get(environment.BACK_URL + 'employees/' + _id);
  }
  updateEmployeeHttp(_id: string, employee: Employee) {
    return this.http.put(environment.BACK_URL + 'employees/' + _id, employee);
  }
  addEmployeeHttp(employee: Employee) {
    return this.http.post(environment.BACK_URL + 'employees', employee);
  }
  deleteEmployeeHttp(_id: string) {
    return this.http.delete(environment.BACK_URL + 'employees/' + _id);
  }
  getEmployee(_id: string): Employee {
    return this.employees.find(employee => employee._id === _id);
  }
  setEmployees(employees: Employee[]) {
    this.employees = employees.slice();
  }

  init() {
    this.isError = false;
    this.errorMessage = '';
    if(this.router.url.split('/')[2].toString() === "new") {
      this.isEditing = false;
      this.initEmployeeForm();      
    } else {
      this.getEmployeeHttp(this.router.url.split('/')[2].toString()).subscribe(resData => {
        this.employee = new Employee(
          resData['employee']._id,
          resData['employee'].firstName,
          resData['employee'].lastName,
          resData['employee'].jobTitle,
          resData['employee'].employmentDate
        );
        this.isEditing = true;  
        this.initEmployeeForm();      
      }, error => {
        this.errorMessage = error.error.Error;
        this.isError = true;
      });             
    }    
  }

  initEmployeeForm() {
    if(this.isEditing) {
      this.employeeForm = this.fb.group({
        ['firstName']: [this.employee.firstName, Validators.compose([Validators.required])],
        ['lastName']: [this.employee.lastName, Validators.compose([Validators.required])],
        ['jobTitle']: [this.employee.jobTitle, Validators.compose([Validators.required])],
        ['employmentDate']: [new Date(this.employee.employmentDate), Validators.compose([Validators.required, this.employmentDateValidator])]
      });
    } else {
      this.employeeForm = this.fb.group({
        ['firstName']: [null, Validators.compose([Validators.required])],
        ['lastName']: [null, Validators.compose([Validators.required])],
        ['jobTitle']: [null, Validators.compose([Validators.required])],
        ['employmentDate']: [null, Validators.compose([Validators.required, this.employmentDateValidator])]
      });
    }
    this.employeeForm.valueChanges.subscribe((value) => {
      this.isError = false;
      this.errorMessage = '';
    });
  }

  employmentDateValidator(control: FormControl): {[s: string]: boolean} {
    let employmentDate = new Date(control.value);
    let todayDate = new Date();
    todayDate.setHours(12);
    todayDate.setMinutes(0);
    todayDate.setSeconds(0);
    todayDate.setMilliseconds(0);

    if(employmentDate.getTime() > todayDate.getTime()) {
      return {'employmentDateInvalid': true};
    }
    return null;
  }

  onSubmit() {
    if(this.isEditing) {
      let e = new Employee(
        this.route.snapshot.params['id'],
        this.employeeForm.get('firstName').value,
        this.employeeForm.get('lastName').value,
        this.employeeForm.get('jobTitle').value,
        this.sharedMethods.adjustDateHours(this.employeeForm.get('employmentDate').value)
      );
      this.updateEmployeeHttp(this.router.url.split('/')[2].toString(), e).subscribe(resData => {
          this.onCancel();
      }, error => {
        this.errorMessage = error.error.Error;
        this.isError = true;
      });
    } else {
      let e = new Employee(
        null,
        this.employeeForm.get('firstName').value,
        this.employeeForm.get('lastName').value,
        this.employeeForm.get('jobTitle').value,
        this.sharedMethods.adjustDateHours(this.employeeForm.get('employmentDate').value)
      );
      this.addEmployeeHttp(e).subscribe(resData => {
          this.onCancel();
      }, error => {
        this.errorMessage = error.error.Error;
        this.isError = true;
      });
    }
  }

  onDelete() {
    this.deleteEmployeeHttp(this.router.url.split('/')[2].toString()).subscribe(resData => {
      this.onCancel();
    }, error => {
      this.errorMessage = error.error.Error;
      this.isError = true;      
    });
  }

  onCancel() {
    this.employeeForm = null;
    this.router.navigate(['']);
  }
}
