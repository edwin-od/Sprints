import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Employee } from './employee.model';

@Injectable({ providedIn: 'root' })
export class EmployeeService {

  employees: Employee[] = [];

  constructor(private http: HttpClient) {}
  getEmployeesHttp() {
    return this.http.get('http://localhost:8080/employees');
  }
  getEmployeeHttp(_id: string) {
    return this.http.get('http://localhost:8080/employees/' + _id);
  }
  updateEmployeeHttp(_id: string, employee: Employee) {
    return this.http.put('http://localhost:8080/employees/' + _id, employee);
  }
  addEmployeeHttp(employee: Employee) {
    return this.http.post('http://localhost:8080/employees', employee);
  }
  deleteEmployeeHttp(_id: string) {
    return this.http.delete('http://localhost:8080/employees/' + _id);
  }
  getEmployee(_id: string): Employee {
    return this.employees.find(employee => employee._id === _id);
  }
  setEmployees(employees: Employee[]) {
    this.employees = employees.slice();
  }
}
