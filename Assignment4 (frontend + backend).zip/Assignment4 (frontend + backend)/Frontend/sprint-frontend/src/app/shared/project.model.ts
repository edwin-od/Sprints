export class Project {
  constructor(
    public _id: string,
    public projectName: string,
    public clientName: string,
    public deliveryDate: any) { }
}
