import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

import { Project } from './project.model';

import { SharedMethods } from './shared-methods.service';

import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ProjectService {

  projects: Project[] = [];

  title = 'Projects';
  
  newRoute = '/projects/new';
  defaultRoute = '/projects';
  
  isEditing: boolean = true;
  isError: boolean = false;

  errorMessage: string = '';

  projectForm: FormGroup;

  project: Project = null;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private fb: FormBuilder,
              private http: HttpClient,
              private sharedMethods: SharedMethods) { }
  getProjectsHttp() {
    return this.http.get(environment.BACK_URL + 'projects');
  }
  getProjectHttp(_id: string) {
    return this.http.get(environment.BACK_URL + 'projects/' + _id);
  }
  updateProjectHttp(_id: string, project: Project) {
    return this.http.put(environment.BACK_URL + 'projects/' + _id, project);
  }
  addProjectHttp(project: Project) {
    return this.http.post(environment.BACK_URL + 'projects', project);
  }
  deleteProjectHttp(_id: string) {
    return this.http.delete(environment.BACK_URL + 'projects/' + _id);
  }
  getProject(_id: string): Project {
    return this.projects.find(project => project._id === _id);
  }
  setProjects(projects: Project[]) {
    this.projects = projects.slice();
  }

  init() {
    this.isError = false;
    this.errorMessage = '';
    if(this.router.url.split('/')[2].toString() === "new") {
      this.isEditing = false;
      this.initProjectForm();      
    } else {
      this.getProjectHttp(this.router.url.split('/')[2].toString()).subscribe(resData => {
        this.project = new Project(
          resData['project']._id,
          resData['project'].projectName,
          resData['project'].clientName,
          resData['project'].deliveryDate
        );
        this.isEditing = true;  
        this.initProjectForm();      
      }, error => {
        this.errorMessage = error.error.Error;
        this.isError = true;
      });             
    }    
  }

  initProjectForm() {
    if(this.isEditing) {
      this.projectForm = this.fb.group({
        ['projectName']: [this.project.projectName, Validators.compose([Validators.required])],
        ['clientName']: [this.project.clientName, Validators.compose([Validators.required])],
        ['deliveryDate']: [new Date(this.project.deliveryDate), Validators.compose([Validators.required, this.deliveryDateValidator])]
      });
    } else {
      this.projectForm = this.fb.group({
        ['projectName']: [null, Validators.compose([Validators.required])],
        ['clientName']: [null, Validators.compose([Validators.required])],
        ['deliveryDate']: [null, Validators.compose([Validators.required, this.deliveryDateValidator])]
      });
    }
    this.projectForm.valueChanges.subscribe((value) => {
      this.isError = false;
      this.errorMessage = '';
    });
  }

  deliveryDateValidator(control: FormControl): {[s: string]: boolean} {
    let deliveryDate = new Date(control.value);
    let todayDate = new Date();
    todayDate.setHours(0);
    todayDate.setMinutes(0);
    todayDate.setSeconds(0);
    todayDate.setMilliseconds(0);

    if(deliveryDate.getTime() < todayDate.getTime()) {
      return {'deliveryDateInvalid': true};
    }
    return null;
  }

  onSubmit() {
    if(this.isEditing) {
      let p = new Project(
        this.router.url.split('/')[2].toString(),
        this.projectForm.get('projectName').value,
        this.projectForm.get('clientName').value,
        this.sharedMethods.adjustDateHours(this.projectForm.get('deliveryDate').value)
      );
      this.updateProjectHttp(this.router.url.split('/')[2].toString(), p).subscribe(resData => {
          this.onCancel();
      }, error => {
        this.errorMessage = error.error.Error;
        this.isError = true;
      });
    } else {
      let p = new Project(
        null,
        this.projectForm.get('projectName').value,
        this.projectForm.get('clientName').value,
        this.sharedMethods.adjustDateHours(this.projectForm.get('deliveryDate').value)
      );
      this.addProjectHttp(p).subscribe(resData => {
          this.onCancel();
      }, error => {
        this.errorMessage = error.error.Error;
        this.isError = true;        
      });
    }
  }

  onDelete() {
    this.deleteProjectHttp(this.router.url.split('/')[2].toString()).subscribe(resData => {
      this.onCancel();
    }, error => {
      this.errorMessage = error.error.Error;
      this.isError = true;
    });
  }

  onCancel() {
    this.projectForm = null;
    this.router.navigate(['']);
  }
}
