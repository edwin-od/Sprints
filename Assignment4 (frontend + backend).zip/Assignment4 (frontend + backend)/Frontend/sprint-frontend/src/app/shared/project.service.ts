import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Project } from './project.model';

@Injectable({ providedIn: 'root' })
export class ProjectService {

  projects: Project[] = [];

  constructor(private http: HttpClient) {}
  getProjectsHttp() {
    return this.http.get('http://localhost:8080/projects');
  }
  getProjectHttp(_id: string) {
    return this.http.get('http://localhost:8080/projects/' + _id);
  }
  updateProjectHttp(_id: string, project: Project) {
    return this.http.put('http://localhost:8080/projects/' + _id, project);
  }
  addProjectHttp(project: Project) {
    return this.http.post('http://localhost:8080/projects', project);
  }
  deleteProjectHttp(_id: string) {
    return this.http.delete('http://localhost:8080/projects/' + _id);
  }
  getProject(_id: string): Project {
    return this.projects.find(project => project._id === _id);
  }
  setProjects(projects: Project[]) {
    this.projects = projects.slice();
  }
}
