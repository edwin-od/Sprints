export class Employee {
  constructor(
    public _id: string,
    public firstName: string,
    public lastName: string,
    public jobTitle: string,
    public employmentDate: any) { }
}
