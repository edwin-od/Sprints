export class Sprint {
  constructor(
    public _id: string,
    public sprintName: string,
    public project: any,
    public employees: any[],
    public startDate: any,
    public endDate: any) { }
}
