import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatRadioModule } from '@angular/material/radio';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatTableModule } from '@angular/material/table';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { LandingComponent } from './landing/landing.component';
import { ProjectListComponent } from './landing/project-list/project-list.component';
import { EmployeeListComponent } from './landing/employee-list/employee-list.component';
import { SprintListComponent } from './landing/sprint-list/sprint-list.component';
import { NotFoundComponent } from './not-found/not-found.component';

import { EmployeesResolver } from './landing/employee-list/employees-resolver.service';
import { ProjectsResolver } from './landing/project-list/projects-resolver.service';
import { SprintsResolver } from './landing/sprint-list/sprints-resolver.service';

import { ProjectsComponent } from './projects/projects.component';
import { EmployeesComponent } from './employees/employees.component';
import { SprintsComponent } from './sprints/sprints.component';
import { ProjectEditComponent } from './projects/project-edit/project-edit.component';
import { ProjectDetailComponent } from './projects/project-detail/project-detail.component';
import { EmployeeEditComponent } from './employees/employee-edit/employee-edit.component';
import { EmployeeDetailComponent } from './employees/employee-detail/employee-detail.component';
import { SprintEditComponent } from './sprints/sprint-edit/sprint-edit.component';
import { SprintDetailComponent } from './sprints/sprint-detail/sprint-detail.component';

@NgModule({
  declarations: [
    AppComponent,
    LandingComponent,
    ProjectListComponent,
    EmployeeListComponent,
    SprintListComponent,
    NotFoundComponent,
    ProjectsComponent,
    EmployeesComponent,
    SprintsComponent,
    ProjectEditComponent,
    ProjectDetailComponent,
    EmployeeEditComponent,
    EmployeeDetailComponent,
    SprintEditComponent,
    SprintDetailComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,    
    HttpClientModule,
    CommonModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatRadioModule,
    MatChipsModule,
    MatIconModule,
    MatMenuModule,
    MatTableModule
  ],
  providers: [
    EmployeesResolver,
    ProjectsResolver,
    SprintsResolver
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
