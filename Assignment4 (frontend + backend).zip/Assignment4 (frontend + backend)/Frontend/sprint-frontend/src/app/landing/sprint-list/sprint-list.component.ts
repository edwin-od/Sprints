import { Component, OnInit, OnDestroy, Input } from '@angular/core';

import { SprintService } from '../../shared/sprint.service';

@Component({
  selector: 'app-sprint-list',
  templateUrl: './sprint-list.component.html',
  styleUrls: ['./sprint-list.component.css']
})
export class SprintListComponent implements OnInit, OnDestroy {

  @Input() sprints;

  constructor() { }

  ngOnInit(): void {
  }

  ngOnDestroy() {
    
  }
}
