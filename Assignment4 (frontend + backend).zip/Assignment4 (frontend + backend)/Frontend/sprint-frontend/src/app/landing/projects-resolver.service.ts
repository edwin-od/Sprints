import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

import { Project } from '../shared/project.model';

import { ProjectService } from '../shared/project.service';

@Injectable()
export class ProjectsResolver implements Resolve<any> {
  constructor(private projectService: ProjectService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
        : Observable<any> | Promise<any> | any {
      return this.projectService.getProjectsHttp();
  }
}
