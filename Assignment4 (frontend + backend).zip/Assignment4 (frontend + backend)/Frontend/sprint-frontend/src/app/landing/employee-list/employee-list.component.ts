import { Component, OnInit, OnDestroy, Input } from '@angular/core';

import { EmployeeService } from '../../shared/employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit, OnDestroy {

  @Input() employees;

  constructor() {}

  ngOnInit(): void {
  }

  ngOnDestroy() {
  }
}
