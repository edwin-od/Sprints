import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Employee } from '../shared/employee.model';
import { Project } from '../shared/project.model';
import { Sprint } from '../shared/sprint.model';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {

  employees: Employee[] = [];
  projects: Project[] = [];
  sprints: Sprint[] = [];

  constructor(private route: ActivatedRoute) {
    this.route.data.subscribe((resData) => {
      this.employees = resData.employeesResolver.employees;
      this.projects = resData.projectsResolver.projects;
      this.sprints = resData.sprintsResolver.sprints;
    });
  }

  ngOnInit(): void {    
  }

}
