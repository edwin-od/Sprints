import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Employee } from '../shared/employee.model';
import { Project } from '../shared/project.model';
import { Sprint } from '../shared/sprint.model';

import { EmployeeService } from '../shared/employee.service';
import { ProjectService } from '../shared/project.service';
import { SprintService } from '../shared/sprint.service';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {

  projectTable = 0;
  employeeTable = 1;
  sprintTable = 2;

  doneFetching = false;

  constructor(private route: ActivatedRoute,
              private es: EmployeeService,
              private ps: ProjectService,
              private ss: SprintService) {
    this.route.data.subscribe((resData) => {
      this.es.employees = resData.employeesResolver.employees;
      this.ps.projects = resData.projectsResolver.projects;
      this.ss.sprints = resData.sprintsResolver.sprints;
      this.doneFetching = true;
    });
  }

  ngOnInit(): void {
  }

}
