import { Component, OnInit, Input } from '@angular/core';

import { EmployeeService } from '../../shared/employee.service';
import { ProjectService } from '../../shared/project.service';
import { SprintService } from '../../shared/sprint.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  @Input() use = -1;

  constructor(public es: EmployeeService,
              public ps: ProjectService,
              public ss: SprintService) { }

  ngOnInit(): void {
  }

  getNewRoute(): string {
    switch(this.use) {
      case 0:
        return this.ps.newRoute;
      case 1:
        return this.es.newRoute;
      case 2:
        return this.ss.newRoute;
      default:
        return '';
    }
  }

  getTitle(): string {
    switch(this.use) {
      case 0:
        return this.ps.title;
      case 1:
        return this.es.title;
      case 2:
        return this.ss.title;
      default:
        return '';
    }
  }

}
