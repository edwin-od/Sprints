import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

import { Employee } from '../shared/employee.model';

import { EmployeeService } from '../shared/employee.service';

@Injectable()
export class EmployeesResolver implements Resolve<any> {
  constructor(private employeeService: EmployeeService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
        : Observable<any> | Promise<any> | any {
      return this.employeeService.getEmployeesHttp();
  }
}
