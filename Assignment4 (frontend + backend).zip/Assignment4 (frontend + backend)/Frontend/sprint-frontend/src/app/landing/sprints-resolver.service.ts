import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

import { Sprint } from '../shared/sprint.model';

import { SprintService } from '../shared/sprint.service';

@Injectable()
export class SprintsResolver implements Resolve<any> {
  constructor(private sprintService: SprintService) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
        : Observable<any> | Promise<any> | any {
      return this.sprintService.getSprintsHttp();
  }
}
